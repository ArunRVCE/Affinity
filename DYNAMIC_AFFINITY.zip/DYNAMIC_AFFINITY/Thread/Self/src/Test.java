import JThreadCore.JThreadCore;
class Test extends JThreadCore{
private static String name;
private static int wait;
private static int pri,afi;
Test(String name,int wait,int pri,int afi){
super(name);
this.name=name; this.wait=wait;
this.pri=pri; this.afi=afi;
setPriority(pri);
setAffinity(afi);
start();
}
public void run(){
try{
for(int i=0;i<5;i++){
System.out.println(i+"\t\t" + getId()+"\t\t\tCPU "+
getAffinity()+ "\t\t" +currentThread()); sleep(wait);
}
}catch(InterruptedException e){System.out.println(e); }
}
public static void main(String s[]){
long startTime,stopTime,elapsedTime;
try{
startTime = System.currentTimeMillis();
System.out.println("Value\tThread Id\tCPU #\t\t\tThread");
System.out.println("----------------------------------------------------------");
Test a1= new Test("one",5,1,0);
Test a2= new Test("two",5,1,1);
Test a3= new Test("three",5,10,0);
Test a4= new Test("four",5,10,1);
a1.join(); a2.join(); a3.join(); a4.join();
stopTime = System.currentTimeMillis();
elapsedTime = (stopTime - startTime)/wait;
System.out.println("Used exection time in ms: " +elapsedTime);
}catch(Exception e){System.out.println(e); }
}
}