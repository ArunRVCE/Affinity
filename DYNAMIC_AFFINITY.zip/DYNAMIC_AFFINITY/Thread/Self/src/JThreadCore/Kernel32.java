package JThreadCore;
import com.sun.jna.Library;
public interface Kernel32 extends Library {
// Select the CPU
int SetThreadAffinityMask(int threadid,int mask);
int GetCurrentThreadId(); // Get thread Id
int Sleep(long Milliseconds); // Assign waiting time
}