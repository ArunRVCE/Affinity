// package name
package JThreadCore;
// inherited with Thread class
public class JThreadCore extends Thread{
// get the available system processor
private int Processors ;
// select the processor to execute the thread
private int ProcessorNum;
//assign the name of the thread
private static String name;
Thread t;
public JThreadCore(String name){
//interchange the thread name value to class variable
this.name=name;
}
public JThreadCore(String name,int ProcessorNum){
//interchange the thread name value to class variable
this.name=name;
//interchange the processor number to class variable
this.ProcessorNum=ProcessorNum;
//call setAffinity method
setAffinity(ProcessorNum);
}
//synchronized method to select the processor
public synchronized void setAffinity(int ProcessorNum){
try{
// interchange processor number to class variable
this.ProcessorNum=ProcessorNum;
//get the available processor in the system
Processors = Runtime.getRuntime().availableProcessors();
//check selected processor is greater than equal to the selected
//processor
if (ProcessorNum>=Processors )
throw new IllegalArgumentException("This processor is not available");
//create threads using loop
for(int i=0; i < Processors ; i++)
//check i value is equal to user selected processor
if (i==ProcessorNum){
//create thread
t=new Thread(name); }
}
catch(Exception e){System.out.println(e);}
}
//get the affinity of the thread
public int getAffinity(){
//return the core number, in which current thread is running
return ProcessorNum;
}
}